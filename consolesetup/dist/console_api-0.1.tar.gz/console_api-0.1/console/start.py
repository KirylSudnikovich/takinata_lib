import sys
import console.parser_api.parser as Parser

def main():
    Parser.parse()


if __name__ == '__main__':
    main()
