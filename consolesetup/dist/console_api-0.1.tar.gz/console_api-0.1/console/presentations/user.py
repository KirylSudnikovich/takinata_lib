def success_reg():
    print("Registration completed successfully")

def success_del():
    print("User delete completed successfully")

def reg_format():
    print(
        "For registration user need to enter the command in the format:\n user register 'username' 'password' "
        "'email'")


def username_edit():
    print("The username was successfully changed")


def password_edit():
    print("The password was successfully changed")


def edit_format():
    print(
        "To change the user, enter the command in the following format:\n user edit 'name/password' 'username'"
        " 'password' 'new value'")


def delete_fotmat():
    print("To delete a user, type the command in the following format:\n user delete 'username' 'password'")


def success_delete():
    print("User was successfully deleted")
