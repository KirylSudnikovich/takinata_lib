"""A package that contains a description of all the entities that are used in the library

__________

Description of internal files

models - description for all exists models

"""
