import unittest
from lib.tests.prep_for_tests import prep

def run_tests():
    testmodules = [
        'lib.tests.project',
        'lib.tests.category',
        'lib.tests.task',
        'lib.tests.user'
    ]

    prep()

    suite = unittest.TestSuite()

    for t in testmodules:
        suite.addTests(unittest.defaultTestLoader.loadTestsFromName(t))

    unittest.TextTestRunner().run(suite)


if __name__ == "__main__":
    run_tests()
