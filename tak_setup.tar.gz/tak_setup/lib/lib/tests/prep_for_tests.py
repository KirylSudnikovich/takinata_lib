from lib.conf import get_prep_for_tests, set_prep_for_tests
from lib.controllers.user import UserController
from lib.controllers.project import ProjectController
from lib.controllers.category import CategoryController
from lib.controllers.task import TaskController

def task_add():
    login = "tester"
    password = "test_password"
    project = ProjectController.get_project_by_name_and_username(login, password, "project_test")
    project_id = project.id
    category = CategoryController.get_category_by_name(project_id, "prep_test_category")
    category_id = category.id
    name = "prep_test_task_new"
    desc = "task description"
    type = 1
    start_date = "10/08/2019"
    start_time = "10:00"
    end_date = "12/08/2020"
    end_time = "13:00"
    priority = "max"
    task = TaskController.add_task(login, password, project_id, category_id, name, desc, type, start_date,
                                   start_time,
                                   end_date, end_time, priority)


def prep():
    ready = get_prep_for_tests()
    if ready == '0':
        UserController.reg("tester", "test_password", "test@test.com")
        UserController.reg("tester2", "test_password", "test@tester.com")
        user = UserController.get_user_by_name('tester')
        ProjectController.create(user.username, user.password, "project_test", "project_desc")
        project = ProjectController.get_project_by_name_and_username(user.username, user.password, "project_test")
        CategoryController.create_category(user.username, user.password, project.id, "prep_test_category", "test desc")
        task_add()
        set_prep_for_tests()
