"""A package that contains a description of all the entities that are used in the library

__________

Description of internal files

column.py - description and fields for Column

project.py - description and fields for Project

regular_task.py - description and fields for Regular Task

task.py - description and fields for Task

user.py - description and fields for User

"""